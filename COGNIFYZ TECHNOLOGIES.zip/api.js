const button = document.getElementById("loadBtn");
const container = document.getElementById("postContainer");

button.addEventListener("click", () => {
  container.innerHTML = "";
  button.disabled = true;
  button.textContent = "Loading...";

  fetch("https://jsonplaceholder.typicode.com/posts")
    .then(response => response.json())
    .then(data => {
      data.slice(0, 5).forEach(post => {
        const div = document.createElement("div");
        div.className = "post";
        div.innerHTML = `
          <h3>${post.title}</h3>
          <p>${post.body}</p>
        `;
        container.appendChild(div);
      });

      button.textContent = "Posts Loaded";
    })
    .catch(error => {
      console.error(error);
      button.textContent = "Error Loading Posts";
    });
});
