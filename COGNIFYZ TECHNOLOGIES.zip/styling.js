const button = document.getElementById("loadBtn");
const container = document.getElementById("postContainer");
const searchInput = document.getElementById("searchInput");
const loader = document.getElementById("loader");
const countText = document.getElementById("countText");

let allPosts = [];

button.addEventListener("click", () => {
  loader.classList.remove("d-none");
  button.disabled = true;
  container.innerHTML = "";
  countText.textContent = "";

  fetch("https://jsonplaceholder.typicode.com/posts")
    .then(res => res.json())
    .then(data => {
      allPosts = data.slice(0, 10);
      renderPosts(allPosts);
      loader.classList.add("d-none");
    });
});

searchInput.addEventListener("input", () => {
  const value = searchInput.value.toLowerCase();
  const filtered = allPosts.filter(post =>
    post.title.toLowerCase().includes(value)
  );
  renderPosts(filtered);
});

function renderPosts(posts) {
  container.innerHTML = "";
  countText.textContent = `Showing ${posts.length} posts`;

  posts.forEach(post => {
    const card = document.createElement("div");
    card.className = "card mb-3";

    card.innerHTML = `
      <div class="card-body">
        <h5 class="card-title">${post.title}</h5>
        <p class="card-text">${post.body}</p>
      </div>
    `;

    container.appendChild(card);
  });
}
