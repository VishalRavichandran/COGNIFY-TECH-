let toggleState = false;

function changeBackground() {
    const page = document.getElementById("pageBody");

    page.style.backgroundColor = toggleState ? "#f6faff" : "#e3f2ff";
    toggleState = !toggleState;
}
